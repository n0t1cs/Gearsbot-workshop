#!/usr/bin/env python3

# Import the necessary libraries
import time
import math
from ev3dev2.motor import *
from ev3dev2.sound import Sound
from ev3dev2.button import Button
from ev3dev2.sensor import *
from ev3dev2.sensor.lego import *
from ev3dev2.sensor.virtual import *

# Create the sensors and motors objects
motorA = LargeMotor(OUTPUT_A)
motorB = LargeMotor(OUTPUT_B)
left_motor = motorA
right_motor = motorB
tank_drive = MoveTank(OUTPUT_A, OUTPUT_B)
steering_drive = MoveSteering(OUTPUT_A, OUTPUT_B)

spkr = Sound()
btn = Button()
radio = Radio()
obtr = ObjectTracker()

color_sensor_in1 = ColorSensor(INPUT_1)
color_sensor_in2 = ColorSensor(INPUT_2)
ultrasonic_sensor_in3 = UltrasonicSensor(INPUT_3)
gyro_sensor_in4 = GyroSensor(INPUT_4)
gps_sensor_in5 = GPSSensor(INPUT_5)

motorC = LargeMotor(OUTPUT_C) # Magnet

# Here is where your code starts

integral = None
last_error = None
base_speed = None
difference = None
derivate = None
corretion = None
VelA = None
VelB = None


integral = 0
last_error = 0
base_speed = 75
while True:
    difference = color_sensor_in1.reflected_light_intensity - color_sensor_in2.reflected_light_intensity
    integral = integral + difference
    derivate = difference - last_error
    corretion = 1.2 * difference + (0 * integral + 0.4 * derivate)
    VelA = base_speed + corretion
    VelB = base_speed - corretion
    VelA = min(max(VelA, -100), 100)
    VelB = min(max(VelB, -100), 100)
    motorA.on(VelA)
    motorB.on(VelB)
    last_error = difference
    time.sleep(0.01)
